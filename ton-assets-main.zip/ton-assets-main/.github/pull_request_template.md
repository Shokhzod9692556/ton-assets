Please make sure you change the original .yaml fields in the accounts/, Collections/ or jettons/ directories and leave the auto-generated .json files in the repository root alone. Also please make sure that you do not use ton.api links in your pull request.
Example pull request:

```yaml
name: the name of your token
description: description of your token
image: "link to your token logo" !!! (don't use ton.api)!!!
address: UQBtn__3IQYPQGp1dgNYUPoaNCbjzgHk56pOWZmqm2ZhN2wF 
symbol: Symbol of your token
websites:
  - "UQBtn__3IQYPQGp1dgNYUPoaNCbjzgHk56pOWZmqm2ZhN2wF"
social:
  - "UQBtn__3IQYPQGp1dgNYUPoaNCbjzgHk56pOWZmqm2ZhN2wF"
```



Пожалуйста, убедитесь, что вы изменили исходные поля .yaml в каталогах account/, Collections/ или jettons/ и не трогаете автоматически сгенерированные файлы .json в корне репозитория. Так же, пожалуйста, убедитесь, что вы не используете ссылки ton.api в вашем пул реквесте.
Пример пул реквеста:

```yaml
name: имя вашего токена
description: описание вашего токена
image: "ссылка на лого вашего токена" !!! (не используйте ton.api)!!!
address: Адрес вашего токена 
symbol: Сивол вашего токена
websites:
  - "ссылка"
social:
  - "ссылка"
  ```
